/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.sukesyunshop.util;