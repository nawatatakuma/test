INSERT INTO warasibe.category(name) value
("書籍"),
("DVD,CD"),
("ゲーム"),
("電化製品"),
("おもちゃ"),
("服、靴、時計"),
("スポーツ用品"),
("その他");