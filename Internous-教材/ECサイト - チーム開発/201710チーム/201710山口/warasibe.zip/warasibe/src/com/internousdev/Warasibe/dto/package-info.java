/**
 * 
 */
/**
 * @author internousdev
 *
 */
package com.internousdev.Warasibe.dto;