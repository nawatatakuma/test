package com.internousdev.ecsite.dto;

public class BuyItemComplete {

}
